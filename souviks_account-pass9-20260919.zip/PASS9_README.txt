SOUVIKS ACCOUNT PASS 9

Includes BOTH requested top-bar changes:
1) Compact authentication avatar — anonymous human icon when signed out; first character of registered name when signed in.
2) Signed-in avatar dropdown — full name, email address, My Account, and Sign Out.

Package type: overlay containing only the two modified files.
Apply on top of the current Pass 7/8 website.
No Supabase schema or catalogue data changes.
